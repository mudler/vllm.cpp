#!/usr/bin/env python3
"""Audit public completion captures and optional model KV profiler evidence.

The public test enters all variants through vllm_engine_load and
vllm_complete_tokens. This audit reads its preserved outputs independently.
Profiler template dtypes and allocation sizes are observations. The matching
16,384-byte KV allocation role is attributed through the recorded source chain.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import struct

from primary import seal


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="the all-19-format operation manifest")
    parser.add_argument("captures", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--profiler", type=Path)
    args = parser.parse_args()
    formats = sorted({c["name"].rsplit("-", 1)[0]
                      for c in json.loads(args.manifest.read_text())["cases"]})
    require(len(formats) == 19, "the public corpus must cover all 19 admitted formats")
    result = {"scope": "same-binary public quantized/dense completion equality; not oracle model token equality",
              "formats": len(formats), "completions": 0, "comparisons": [], "files": {}}
    expected_files = set()
    for name in formats:
        first = {}
        for repeat in range(3):
            for prompt in range(2):
                pair = {}
                for arm in ("quant", "dense"):
                    prefix = f"{name}-r{repeat}-p{prompt}-{arm}"
                    ids_path = args.captures / (prefix + "-tokens.txt")
                    logits_path = args.captures / (prefix + "-logits-f32.bin")
                    ids = [int(word) for word in ids_path.read_text().split()]
                    logits = logits_path.read_bytes()
                    require(len(ids) == 4 and all(0 <= token < 128 for token in ids),
                            "a public completion must contain four in-range token IDs")
                    require(len(logits) == 4 * 128 * 4, "a public completion must preserve all 512 F32 logits")
                    require(all(math.isfinite(value) for (value,) in struct.iter_unpack("<f", logits)),
                            "a public completion contains nonfinite logits")
                    pair[arm] = (ids, logits)
                    for path in (ids_path, logits_path):
                        expected_files.add(path.name)
                        result["files"][str(path)] = seal(path)
                    result["completions"] += 1
                require(pair["quant"] == pair["dense"], "quantized and dense public outputs differ")
                if repeat == 0:
                    first[prompt] = pair["quant"]
                else:
                    require(pair["quant"] == first[prompt], "a fresh-engine repeat changed public output bytes")
                result["comparisons"].append({"format": name, "repeat": repeat, "prompt_index": prompt,
                                              "tokens": pair["quant"][0], "dense_and_repeat_exact": True})
    require({p.name for p in args.captures.iterdir() if p.is_file()} == expected_files,
            "the capture directory has missing or unexplained files")
    if args.profiler is not None:
        def rows(suffix: str) -> list[dict]:
            paths = list(args.profiler.glob(f"*_{suffix}.csv"))
            require(len(paths) == 1, "expected one complete public-test process trace")
            result["files"][str(paths[0])] = seal(paths[0])
            with paths[0].open() as file:
                return list(csv.DictReader(file))

        kernels = rows("kernel_trace")
        api = {r["Correlation_Id"]: r["Function"] for r in rows("hip_api_trace")}
        allocations = rows("memory_allocation_trace")
        writes = [r for r in kernels if "ReshapeAndCacheK<" in r["Kernel_Name"]]
        reads = [r for r in kernels if "PagedAttnOnline<" in r["Kernel_Name"]]
        gathers = [r for r in kernels if "EmbeddingQuantGatherKernel<" in r["Kernel_Name"]]
        require(len(writes) == len(reads) == result["completions"] * 4,
                "each public prefill/decode must execute its cache write and attention kernel")
        require(all("ReshapeAndCacheK<unsigned short>" in r["Kernel_Name"] for r in writes),
                "public cache writes must use two-byte storage")
        require(all("PagedAttnOnline<float, __hip_bfloat16, float>" in r["Kernel_Name"] for r in reads),
                "public attention must read BF16 cache storage")
        require(len(gathers) == result["completions"] // 2 * 4 and
                all("EmbeddingQuantGatherKernel<unsigned short," in r["Kernel_Name"] for r in gathers),
                "every quantized public model must gather directly into its BF16 output")
        require(all(r["Correlation_Id"] in api for r in reads + writes + gathers),
                "an attributed public kernel lacks its HIP API correlation")
        matching = [r for r in allocations if r["Operation"] == "MEMORY_ALLOCATION_ALLOCATE"
                    and api.get(r["Correlation_Id"]) == "hipMalloc" and int(r["Allocation_Size"]) == 16384]
        require(len(matching) == result["completions"], "expected one matching KV-sized allocation per engine")
        result["native_model_memory"] = {
            "observed_bf16_cache_reads": len(reads), "observed_two_byte_cache_writes": len(writes),
            "observed_direct_bf16_quantized_gathers": len(gathers),
            "observed_16384_byte_hipmalloc_allocations": len(matching),
            "source_attribution": "runner.cpp:1571-1574 allocates num_blocks*page_size; kv_cache_interface.cpp:114-116 sizes16*1*(64+64)*2=4096 bytes/page; four pages=16384",
            "attribution_limit": "The profiler records allocation size, not its semantic buffer name; its one-per-engine match is read with the cache source chain",
            "oracle_model_memory_parity": "PENDING: primary refuses, secondary models abort and pad64cells to256"}
    result["pass"] = True
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(f"PASS: {result['completions']} public completions preserve exact dense-control and repeat token/logit bytes")


if __name__ == "__main__":
    main()
