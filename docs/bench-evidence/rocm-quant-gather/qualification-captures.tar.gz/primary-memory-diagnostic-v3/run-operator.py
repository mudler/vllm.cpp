import fcntl,hashlib,json,os,subprocess,time
from pathlib import Path
R=Path(__file__).parent
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=R/'commands.json'
assert sha(p)=='fbf511613cd4fc9c23a78754f7179edab074e02fa001ff419936fdd38ed7ebd3'
r=json.loads(p.read_text())
files={k:v['sha256'] for k,v in r['files'].items()}
base=json.loads(Path('/home/vikash/.cache/rdna3-gather-impl/primary-model-v5/operator-input-audit.json').read_text())['files']
for k,v in base.items():
 if '/site-packages/vllm/' in k or '/plugin-artifact/' in k:files[k]=v
files[str(p)]=sha(p);files[str(Path(__file__))]=sha(__file__)
for k,v in files.items():assert sha(k)==v,k
(R/'operator-input-audit.json').write_text(json.dumps({'files':files,'command':r},indent=2)+'\n')
with open('/home/vikash/gpu.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 argv=r['argv'];name=argv[argv.index('--name')+1]
 assert name not in subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines()
 logpath=Path(r['log']);assert not logpath.exists();start=time.monotonic()
 with logpath.open('w') as log:
  idle=subprocess.run(['/opt/rocm/bin/rocm-smi','--showuse','--showpids'],stdout=log,stderr=subprocess.STDOUT);assert idle.returncode==0
  try:code=subprocess.run(argv,cwd=r['cwd'],env=dict(os.environ,**r['env']),stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
  except subprocess.TimeoutExpired:
   code=124;subprocess.run(['docker','rm','-f',name],stdout=log,stderr=subprocess.STDOUT,timeout=30)
 for k,v in files.items():assert sha(k)==v,k
 result={'exit_code':code,'seconds':time.monotonic()-start,'log_sha256':sha(logpath),'inputs_verified_before_after':len(files),'input_audit_sha256':sha(R/'operator-input-audit.json')}
 (R/'operator-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True);print(logpath.read_text()[-5000:],flush=True)
 raise SystemExit(code)
