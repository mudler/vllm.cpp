import hashlib,json,os,subprocess,sys,time
from pathlib import Path
R=Path(sys.argv[1]);p=R/'commands.json'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(p)==sys.argv[2]
r=json.loads(p.read_text());files={k:v['sha256'] for k,v in r['files'].items()};files[str(p)]=sha(p);files[str(Path(__file__))]=sha(__file__)
for k,v in files.items():assert sha(k)==v,k
(R/'operator-input-audit.json').write_text(json.dumps({'files':files,'runs':r['runs']},indent=2)+'\n');results=[]
for c in r['runs']:
 logpath=Path(c['log']);assert not logpath.exists();start=time.monotonic()
 with logpath.open('w') as log:code=subprocess.run(c['argv'],cwd=c['cwd'],env=dict(os.environ,**c['env']),stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
 result={'name':c['name'],'exit_code':code,'expected_exit':c['expected_exit'],'seconds':time.monotonic()-start,'log_sha256':sha(logpath)};results.append(result)
 
 if 'expected_output' in c:
  x=c['expected_output'];p=Path(x['path']);result['output_matches']=p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
 print(json.dumps(result),flush=True)
for k,v in files.items():assert sha(k)==v,k
(R/'operator-receipt.json').write_text(json.dumps({'results':results,'inputs_verified_before_after':len(files)},indent=2)+'\n')
assert all(x['exit_code']==x['expected_exit'] and x.get('output_matches',True) for x in results)
